require 'twitter'

class HomeController < ApplicationController
  rescue_from Twitter::Unauthorized, :with => :force_sign_in
  def index
  end
  
  def login
    username = params[:screenname]
    password = params[:password]
    
    http_auth = Twitter::HTTPAuth.new(username,password)
    client = Twitter::Base.new(http_auth)
    
    @username = username
    @followers_info = 
        client.followers.map do |f|
            { :screenname => f.screen_name, :tweets => f.statuses_count }
        end
        
    render :index
  end

  private
  
    def force_sign_in(exception)
      flash[:error] = "Failed to log in " + params[:screenname]
      redirect_to :action => "index"
    end
end
